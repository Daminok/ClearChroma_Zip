package com.damirsoft.androidclearchroma;

/**
 * Enumeration of each form available for preview.
 * @author JJamet
 */
public enum ShapePreviewPreference {
    CIRCLE,
    SQUARE,
    ROUNDED_SQUARE
}
